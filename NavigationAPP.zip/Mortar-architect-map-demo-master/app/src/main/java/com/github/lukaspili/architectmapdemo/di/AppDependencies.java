package com.github.lukaspili.architectmapdemo.di;

/**
 * @author Lukasz Piliszczuk - lukasz.pili@gmail.com
 */
public interface AppDependencies {

}
